require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const connectDB = require('./config/database');
const HealthRecord = require('./models/HealthRecord');
const Appointment = require('./models/Appointment');
const Order = require('./models/Order');
const Report = require('./models/Report');
const Emergency = require('./models/Emergency');
const Admin = require('./models/Admin');
const { authenticateAdmin, JWT_SECRET } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to MongoDB (with error handling)
connectDB().catch(err => {
  console.log('MongoDB not connected, using in-memory storage');
  console.log('To enable database, install MongoDB or use MongoDB Atlas');
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// In-memory storage fallback (when MongoDB not available)
let inMemoryAppointments = [];
let inMemoryHealthRecords = [];
let inMemoryOrders = [];
let inMemoryReports = [];
let inMemoryEmergencies = [];

// Health Records API
app.get('/api/health-records', async (req, res) => {
  try {
    const records = await HealthRecord.find().sort({ createdAt: -1 });
    res.json(records);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryHealthRecords);
  }
});

app.post('/api/health-records', async (req, res) => {
  try {
    const record = new HealthRecord(req.body);
    await record.save();
    res.json(record);
  } catch (error) {
    // Fallback to in-memory storage
    const record = {
      _id: Date.now().toString(),
      ...req.body,
      createdAt: new Date().toISOString()
    };
    inMemoryHealthRecords.push(record);
    res.json(record);
  }
});

app.put('/api/health-records/:id', async (req, res) => {
  try {
    const record = await HealthRecord.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!record) {
      return res.status(404).json({ error: 'Record not found' });
    }
    res.json(record);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/health-records/:id', async (req, res) => {
  try {
    const record = await HealthRecord.findByIdAndDelete(req.params.id);
    if (!record) {
      return res.status(404).json({ error: 'Record not found' });
    }
    res.json({ message: 'Record deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Appointments API
app.get('/api/appointments', async (req, res) => {
  try {
    const appointments = await Appointment.find().sort({ createdAt: -1 });
    res.json(appointments);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryAppointments);
  }
});

app.post('/api/appointments', async (req, res) => {
  try {
    const appointment = new Appointment(req.body);
    await appointment.save();
    res.json(appointment);
  } catch (error) {
    // Fallback to in-memory storage
    const appointment = {
      _id: Date.now().toString(),
      ...req.body,
      createdAt: new Date().toISOString()
    };
    inMemoryAppointments.push(appointment);
    res.json(appointment);
  }
});

app.put('/api/appointments/:id', async (req, res) => {
  try {
    const appointment = await Appointment.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!appointment) {
      // Try in-memory
      const index = inMemoryAppointments.findIndex(a => a._id === req.params.id);
      if (index !== -1) {
        inMemoryAppointments[index] = { ...inMemoryAppointments[index], ...req.body };
        return res.json(inMemoryAppointments[index]);
      }
      return res.status(404).json({ error: 'Appointment not found' });
    }
    res.json(appointment);
  } catch (error) {
    // Fallback to in-memory storage
    const index = inMemoryAppointments.findIndex(a => a._id === req.params.id);
    if (index !== -1) {
      inMemoryAppointments[index] = { ...inMemoryAppointments[index], ...req.body };
      return res.json(inMemoryAppointments[index]);
    }
    res.status(404).json({ error: 'Appointment not found' });
  }
});

// Medicines API
app.get('/api/medicines', (req, res) => {
  const medicinesList = [
    { id: '1', name: 'Paracetamol 500mg', price: 25, stock: 100, category: 'Pain Relief' },
    { id: '2', name: 'Amoxicillin 250mg', price: 150, stock: 50, category: 'Antibiotic' },
    { id: '3', name: 'Cetirizine 10mg', price: 30, stock: 75, category: 'Antihistamine' },
    { id: '4', name: 'Omeprazole 20mg', price: 80, stock: 60, category: 'Antacid' },
    { id: '5', name: 'Metformin 500mg', price: 120, stock: 40, category: 'Diabetes' },
    { id: '6', name: 'Atorvastatin 10mg', price: 200, stock: 30, category: 'Cholesterol' }
  ];
  res.json(medicinesList);
});

app.post('/api/orders', async (req, res) => {
  try {
    const order = new Order(req.body);
    await order.save();
    res.json(order);
  } catch (error) {
    // Fallback to in-memory storage
    const order = {
      _id: Date.now().toString(),
      ...req.body,
      createdAt: new Date().toISOString()
    };
    inMemoryOrders.push(order);
    res.json(order);
  }
});

app.get('/api/orders', async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryOrders);
  }
});

// Reports API
app.get('/api/reports', async (req, res) => {
  try {
    const reports = await Report.find().sort({ createdAt: -1 });
    res.json(reports);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryReports);
  }
});

app.post('/api/reports', async (req, res) => {
  try {
    const report = new Report(req.body);
    await report.save();
    res.json(report);
  } catch (error) {
    // Fallback to in-memory storage
    const report = {
      _id: Date.now().toString(),
      ...req.body,
      createdAt: new Date().toISOString()
    };
    inMemoryReports.push(report);
    res.json(report);
  }
});

app.delete('/api/reports/:id', async (req, res) => {
  try {
    const report = await Report.findByIdAndDelete(req.params.id);
    if (!report) {
      return res.status(404).json({ error: 'Report not found' });
    }
    res.json({ message: 'Report deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Emergency Services API
app.post('/api/emergency', async (req, res) => {
  try {
    const emergency = new Emergency(req.body);
    await emergency.save();
    res.json(emergency);
  } catch (error) {
    // Fallback to in-memory storage
    const emergency = {
      _id: Date.now().toString(),
      ...req.body,
      status: 'dispatched',
      createdAt: new Date().toISOString()
    };
    inMemoryEmergencies.push(emergency);
    res.json(emergency);
  }
});

// Doctors API
app.get('/api/doctors', (req, res) => {
  const doctors = [
    { id: '1', name: 'Dr. Sarah Johnson', specialization: 'Cardiologist', experience: '15 years', rating: 4.8 },
    { id: '2', name: 'Dr. Michael Chen', specialization: 'Pediatrician', experience: '12 years', rating: 4.9 },
    { id: '3', name: 'Dr. Emily Davis', specialization: 'Dermatologist', experience: '10 years', rating: 4.7 },
    { id: '4', name: 'Dr. James Wilson', specialization: 'Orthopedic', experience: '18 years', rating: 4.9 },
    { id: '5', name: 'Dr. Lisa Anderson', specialization: 'Gynecologist', experience: '14 years', rating: 4.8 }
  ];
  res.json(doctors);
});

// Lab Tests API
app.get('/api/lab-tests', (req, res) => {
  const labTests = [
    { id: '1', name: 'Complete Blood Count (CBC)', price: 500, duration: '24 hours' },
    { id: '2', name: 'Blood Glucose Test', price: 300, duration: '4 hours' },
    { id: '3', name: 'Lipid Profile', price: 600, duration: '24 hours' },
    { id: '4', name: 'Thyroid Function Test', price: 800, duration: '24 hours' },
    { id: '5', name: 'Liver Function Test', price: 700, duration: '24 hours' },
    { id: '6', name: 'ECG', price: 400, duration: '1 hour' }
  ];
  res.json(labTests);
});

// Admin Authentication Routes
app.post('/api/admin/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    
    // Check if admin already exists
    const existingAdmin = await Admin.findOne({ $or: [{ email }, { username }] });
    if (existingAdmin) {
      return res.status(400).json({ error: 'Admin already exists' });
    }

    const admin = new Admin({ username, email, password });
    await admin.save();
    
    const token = jwt.sign({ adminId: admin._id }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, admin: { id: admin._id, username: admin.username, email: admin.email } });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/admin/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    const admin = await Admin.findOne({ email });
    if (!admin) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isMatch = await admin.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ adminId: admin._id }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, admin: { id: admin._id, username: admin.username, email: admin.email } });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin Dashboard Stats (no auth required)
app.get('/api/admin/stats', async (req, res) => {
  try {
    const [healthRecords, appointments, orders, reports, emergencies] = await Promise.all([
      HealthRecord.countDocuments().catch(() => inMemoryHealthRecords.length),
      Appointment.countDocuments().catch(() => inMemoryAppointments.length),
      Order.countDocuments().catch(() => inMemoryOrders.length),
      Report.countDocuments().catch(() => inMemoryReports.length),
      Emergency.countDocuments().catch(() => inMemoryEmergencies.length)
    ]);

    const pendingOrders = await Order.countDocuments({ status: 'pending' }).catch(() => 
      inMemoryOrders.filter(o => o.status === 'pending').length
    );
    const scheduledAppointments = await Appointment.countDocuments({ status: 'scheduled' }).catch(() =>
      inMemoryAppointments.filter(a => a.status === 'scheduled').length
    );
    const totalRevenue = await Order.aggregate([
      { $match: { status: 'delivered' } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } }
    ]).catch(() => {
      const delivered = inMemoryOrders.filter(o => o.status === 'delivered');
      return [{ total: delivered.reduce((sum, o) => sum + (o.totalAmount || 0), 0) }];
    });

    res.json({
      healthRecords,
      appointments,
      orders,
      reports,
      emergencies,
      pendingOrders,
      scheduledAppointments,
      totalRevenue: totalRevenue[0]?.total || 0
    });
  } catch (error) {
    // Fallback stats
    res.json({
      healthRecords: inMemoryHealthRecords.length,
      appointments: inMemoryAppointments.length,
      orders: inMemoryOrders.length,
      reports: inMemoryReports.length,
      emergencies: inMemoryEmergencies.length,
      pendingOrders: inMemoryOrders.filter(o => o.status === 'pending').length,
      scheduledAppointments: inMemoryAppointments.filter(a => a.status === 'scheduled').length,
      totalRevenue: 0
    });
  }
});

// Admin - Get All Health Records (no auth required)
app.get('/api/admin/health-records', async (req, res) => {
  try {
    const records = await HealthRecord.find().sort({ createdAt: -1 });
    res.json(records);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryHealthRecords);
  }
});

// Admin - Delete Health Record (no auth required)
app.delete('/api/admin/health-records/:id', async (req, res) => {
  try {
    await HealthRecord.findByIdAndDelete(req.params.id);
    res.json({ message: 'Record deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Admin - Get All Appointments (no auth required)
app.get('/api/admin/appointments', async (req, res) => {
  try {
    const appointments = await Appointment.find().sort({ createdAt: -1 });
    res.json(appointments);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryAppointments);
  }
});

// Admin - Update Appointment Status (no auth required)
app.put('/api/admin/appointments/:id', async (req, res) => {
  try {
    const appointment = await Appointment.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(appointment);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Admin - Get All Orders (no auth required)
app.get('/api/admin/orders', async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryOrders);
  }
});

// Admin - Update Order Status (no auth required)
app.put('/api/admin/orders/:id', async (req, res) => {
  try {
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(order);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Admin - Get All Reports (no auth required)
app.get('/api/admin/reports', async (req, res) => {
  try {
    const reports = await Report.find().sort({ createdAt: -1 });
    res.json(reports);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryReports);
  }
});

// Admin - Get All Emergencies (no auth required)
app.get('/api/admin/emergencies', async (req, res) => {
  try {
    const emergencies = await Emergency.find().sort({ createdAt: -1 });
    res.json(emergencies);
  } catch (error) {
    // Fallback to in-memory storage
    res.json(inMemoryEmergencies);
  }
});

// Admin - Update Emergency Status (no auth required)
app.put('/api/admin/emergencies/:id', async (req, res) => {
  try {
    const emergency = await Emergency.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(emergency);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Admin - Manage Doctors (no auth required)
app.get('/api/admin/doctors', (req, res) => {
  const doctors = [
    { id: '1', name: 'Dr. Sarah Johnson', specialization: 'Cardiologist', experience: '15 years', rating: 4.8 },
    { id: '2', name: 'Dr. Michael Chen', specialization: 'Pediatrician', experience: '12 years', rating: 4.9 },
    { id: '3', name: 'Dr. Emily Davis', specialization: 'Dermatologist', experience: '10 years', rating: 4.7 },
    { id: '4', name: 'Dr. James Wilson', specialization: 'Orthopedic', experience: '18 years', rating: 4.9 },
    { id: '5', name: 'Dr. Lisa Anderson', specialization: 'Gynecologist', experience: '14 years', rating: 4.8 }
  ];
  res.json(doctors);
});

// Admin - Manage Lab Tests (no auth required)
app.get('/api/admin/lab-tests', (req, res) => {
  const labTests = [
    { id: '1', name: 'Complete Blood Count (CBC)', price: 500, duration: '24 hours' },
    { id: '2', name: 'Blood Glucose Test', price: 300, duration: '4 hours' },
    { id: '3', name: 'Lipid Profile', price: 600, duration: '24 hours' },
    { id: '4', name: 'Thyroid Function Test', price: 800, duration: '24 hours' },
    { id: '5', name: 'Liver Function Test', price: 700, duration: '24 hours' },
    { id: '6', name: 'ECG', price: 400, duration: '1 hour' }
  ];
  res.json(labTests);
});

// Admin - Manage Medicines (no auth required)
app.get('/api/admin/medicines', (req, res) => {
  const medicines = [
    { id: '1', name: 'Paracetamol 500mg', price: 25, stock: 100, category: 'Pain Relief' },
    { id: '2', name: 'Amoxicillin 250mg', price: 150, stock: 50, category: 'Antibiotic' },
    { id: '3', name: 'Cetirizine 10mg', price: 30, stock: 75, category: 'Antihistamine' },
    { id: '4', name: 'Omeprazole 20mg', price: 80, stock: 60, category: 'Antacid' },
    { id: '5', name: 'Metformin 500mg', price: 120, stock: 40, category: 'Diabetes' },
    { id: '6', name: 'Atorvastatin 10mg', price: 200, stock: 30, category: 'Cholesterol' }
  ];
  res.json(medicines);
});

app.listen(PORT, async () => {
  console.log(`Server is running on port ${PORT}`);
  
  // Create default admin if none exists
  try {
    const adminCount = await Admin.countDocuments();
    if (adminCount === 0) {
      const defaultAdmin = new Admin({
        username: 'admin',
        email: 'admin@medic.com',
        password: 'admin123'
      });
      await defaultAdmin.save();
      console.log('Default admin created:');
      console.log('Email: admin@medic.com');
      console.log('Password: admin123');
    }
  } catch (error) {
    console.log('Error creating default admin:', error.message);
  }
});

